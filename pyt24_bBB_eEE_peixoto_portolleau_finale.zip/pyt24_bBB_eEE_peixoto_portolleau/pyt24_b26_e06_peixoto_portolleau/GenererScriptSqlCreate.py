import re
from os import chdir

# Changement du répertoire de travail
chdir("/home/btssio/Documents/Etape6")

# Ouverture du fichier contenant les mots de passe
with open('usersPassword.csv', 'r') as f_password:
    lignes_password = f_password.readlines()

# Retrait des virgules des mots de passe
lignes_password = [ligne.strip().replace(',', '') for ligne in lignes_password]

# Ouverture du fichier contenant les informations des utilisateurs
with open('usersToulouse.csv', 'r') as f_toulouse:
    lignes_toulouse = f_toulouse.readlines()

# Ouverture du fichier de sortie SQL
with open('creerUsersBddAcces.sql', 'w') as f_sql:
    # Parcours de chaque ligne du fichier d'utilisateurs de Toulouse
    for ligne_toulouse in lignes_toulouse:
        # Recherche de la séquence 'CN=' dans chaque ligne
        match = re.search(r'CN=([^,]+)', ligne_toulouse)
        if match:
            # Séparation des mots après 'CN='
            mots_apres_cn = match.group(1).split()
            # Vérification s'il y a au moins deux mots
            if len(mots_apres_cn) >= 2:
                # Conversion des mots en minuscules
                premier_mot = mots_apres_cn[0].lower()
                premiere_lettre_second_mot = mots_apres_cn[1][0].lower()
                # Construction de l'identifiant inversé
                identifiant_inverse = f"{premiere_lettre_second_mot}{premier_mot}"

                # Récupération du mot de passe correspondant depuis le fichier usersPassword.csv
                mot_de_passe_index = lignes_toulouse.index(ligne_toulouse)
                if mot_de_passe_index < len(lignes_password):
                    mot_de_passe = lignes_password[mot_de_passe_index].strip()
                else:
                    mot_de_passe = "motdepassepardefaut"  # Mot de passe par défaut si indisponible

                # Écriture de la création de l'utilisateur SQL avec les privilèges spécifiques
                f_sql.write(f"CREATE USER '{identifiant_inverse}'@'localhost' IDENTIFIED BY '{mot_de_passe}';\n")

                # Écriture de la création de la base de données SQL
                f_sql.write(f"CREATE DATABASE IF NOT EXISTS db{identifiant_inverse};\n")

                # Attribution des privilèges spécifiques sur la base de données
                f_sql.write(f"GRANT CREATE, ALTER, DROP, INSERT, UPDATE, DELETE, SELECT ON db{identifiant_inverse}.* TO '{identifiant_inverse}'@'localhost';\n")








